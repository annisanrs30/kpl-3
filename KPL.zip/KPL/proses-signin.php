<?php
  session_start();
  include('functions.php'); 
  

  	$email = $_POST ['email'];
  	$password = MD5($_POST['password']);

  	$query  = "SELECT * FROM user WHERE email='$email' AND password='$password'";
	$result     = mysqli_query($conn, $query);
	$num_row     = mysqli_num_rows($result);
	
	if (isset($_POST["login"])) {
    try {
        //code...
        if (login($_POST) == false) {
            throw new Exception("email / password Salah");
        }
        header('location: index_landing.php');
        exit;
    } catch (Exception $error) {
        echo "<script>
        alert ('" . $error->getMessage() . "');
            document.location.href = 'index_signin.php';
        </script>";
    }
	}

	if($num_row >=1) {
		$row         = mysqli_fetch_array($result);
	    $_SESSION['id'] = $row['id'];
	    echo "<script>alert('Login Berhasil');window.location='index_landing.php';</script>"; 
	} else {
	    
	    echo "<script>alert('Login Gagal');window.location='index_signin.php';</script>";
	}
?>