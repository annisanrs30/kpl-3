<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Register ANRS</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="shortcut icon" href="img/lg.png">
  <style>
    body {
      font-family: "Muli", sans-serif;
      background-color: #fff7e3;
    }

    .navbar nav {
      margin: auto;
      text-align: center;
      width: 100%;
    }

    .navbar nav ul ul {
      display: none;
    }

    .navbar nav ul li:hover>ul {
      display: block;
      width: 150px;
    }

    .navbar nav ul {
      background: #fff7e3;
      padding: 0 20px;
      list-style: none;
      position: relative;
      display: inline-table;
      width: 100%;
    }

    .navbar nav ul:after {
      content: "";
      clear: both;
      display: block;
    }

    .navbar nav ul li {
      float: right;
    }

    .navbar nav ul li:hover {
      background: #A2A2A2;
    }

    .navbar nav ul:hover a {
      color: #000;
    }

    .navbar nav ul li a {
      display: block;
      padding: 25px;
      color: #000;
      text-decoration: none;
      font-family: "Muli", sans-serif;
      font-size: 20px;
    }

    .navbar nav ul ul {
      background: #FBBC58;
      border-radius: 0px;
      padding: 0;
      position: absolute;
      top: 100%;
    }

    .navbar nav ul ul ul {
      position: absolute;
      right: 90%;
      top: 0;
    }

    #card {
      background: #ffff;
      border-radius: 8px;
      box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
      height: 650px;
      margin: 6rem auto 8.1rem auto;
      width: 459px;
      margin-top: 30px;
      margin-bottom: 70px;
    }

    body {
      background: #fff7e3;
      background-repeat: no-repeat;
    }

    #card-content {
      padding: 12px 44px;
    }

    #card-title {
      font-family: "Muli", sans-serif;
      letter-spacing: 4px;
      padding-bottom: 23px;
      padding-top: 13px;
      text-align: center;
      margin-top: 30px;
    }

    .underline-title {
      background: -webkit-linear-gradient(right, #D0D0D0, #000);
      height: 2px;
      margin: 0.1rem auto 0 auto;
      width: 133px;
    }

    a {
      text-decoration: none;
    }

    label {
      font-family: "Muli", sans-serif;
      font-size: 11pt;
    }

    #forgot-pass {
      color: #2e302f;
      font-family: "Muli", sans-serif;
      font-size: 10pt;
      margin-top: 3px;
      text-align: right;
    }

    .form {
      align-items: left;
      display: flex;
      flex-direction: column;
    }

    .form-border {
      background: -webkit-linear-gradient(right, #ffff, #000);
      height: 1px;
      width: 100%;
    }

    .form-content {
      background: #ffff;
      border: none;
      outline: none;
      padding-top: 14px;
    }

    #signup {
      color: #2e302f;
      font-family: "Muli", sans-serif;
      font-size: 10pt;
      margin-top: 16px;
      text-align: center;
    }

    #submit-btn {
      background: #A5A5A5;
      border: none;
      border-radius: 21px;
      box-shadow: 0px 1px 8px #888b8a;
      cursor: pointer;
      color: #000;
      font-family: "Muli", sans-serif;
      height: 42.3px;
      margin: 0 auto;
      margin-top: 50px;
      margin-bottom: 10px;
      transition: 0.25s;
      width: 153px;
      outline: none;
    }

    #submit-btn:hover {
      box-shadow: 0px 1px 18px#2e302f;
    }

    .asking {
      margin: auto;
      justify-content: space-between;
      font-family: "Muli", sans-serif;
      font-size: 13px;
    }

    .footer {
      padding: 50px 0;
      color: #000;
      background-color: #EBE4D3;
    }

    .footer h3 {
      margin-top: 0;
      margin-bottom: 12px;
      font-weight: bold;
      font-size: 16px;
    }

    .footer ul {
      padding: 0;
      list-style: none;
      line-height: 1.6;
      font-size: 14px;
      margin-bottom: 0;
    }

    .footer ul a {
      color: inherit;
      text-decoration: none;
      opacity: 0.6;
    }

    .footer ul a:hover {
      opacity: 0.8;
    }

    @media (max-width:767px) {
      .footer .item:not(.social) {
        text-align: center;
        padding-bottom: 20px;
      }
    }

    .footer .item.text {
      margin-bottom: 36px;
    }

    @media (max-width:767px) {
      .footer .item.text {
        margin-bottom: 0;
      }
    }

    .footer .item.text p {
      opacity: 0.6;
      margin-bottom: 0;
    }

    .footer .item.social {
      text-align: center;
    }

    @media (max-width:991px) {
      .footer .item.social {
        text-align: center;
        margin-top: 20px;
      }
    }

    .footer .item.social>a {
      font-size: 20px;
      width: 36px;
      height: 36px;
      line-height: 36px;
      display: inline-block;
      text-align: center;
      border-radius: 50%;
      box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.4);
      margin: 0 8px;
      margin-top: 10px;
      color: #000;
      opacity: 0.75;
    }

    .footer .item.social>a:hover {
      opacity: 0.9;
    }

    .footer .copyright {
      text-align: center;
      padding-top: 24px;
      opacity: 0.3;
      font-size: 13px;
      margin-bottom: 0;
    }
  </style>

</head>

<body>
  <div class="navbar">
    <nav>
      <ul>
        <li style="margin-top: 30px;"><a href="index_signin.php">Login</a></li>
        <li style="margin-top: 30px;"><a href="index_signup.php">Register</a></li>
        <li style="margin-top: 30px;"><a href="index_landing.php">Home</a></li>
        <li style="margin-top: -110px; margin-right: 992px;">
          <a href="index_landing.php">
            <img src="img/lg.png" style="height: 85px; width: 85px;">
            ANRS Konversi & Balok</a>
        </li>
      </ul>
    </nav>
  </div>

  <div class="container-fluid" id="codelatte">
    <div id="card">
      <div id="card-content">
        <div id="card-title">
          <h2 style="font-size: 30px;">Register</h2>
          <div class="underline-title"></div>
        </div>
        <form action="proses-signup.php" method="post" class="form">
          <label for="username" style="padding-top:13px">Username</label>
          <input id="username" class="form-content" type="text" name="username" autocomplete="on" required />
          <div class="form-border"></div>

          <label for="email" style="padding-top:13px">Email</label>
          <input id="email" class="form-content" type="email" name="email" autocomplete="on" required />
          <div class="form-border"></div>

          <label for="password" style="padding-top:22px">Password</label>
          <input id="password" class="form-content" type="password" name="password" autocomplete="on" required />
          <div class="form-border"></div>
          
         <button  id="submit-btn" type="submit" value ="Simpan" name="proses">Register</button>
          
          <div class="asking">
            <a style="color: #000;">
              already have an account?</a>
            <a href="index_signin.php" style="color: #blue;">
              Login</a>
          </div>
        </form>
       
      </div>
    </div>
  </div>

  <div class="footer">
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-3 item">
            <h3>Contact</h3>
              <ul>
                <li><a href="https://wa.me/6285648337761?text=Isi Pesan"><i class="icon ion-social-whatsapp"></i> 085648337761</a></li>
              </ul>
          </div>
          <div class="col-md-6 item text">
            <h3>ANRS Konversi & Balok</h3>
            <p>Kami Akan Memberi Yang Terbaik Untuk Anda !</p>
          </div>
        </div>
        <p class="copyright">Copyright © 2021 ANRS Konversi & Balok. All Rights Reserved </p>
      </div>
    </footer>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
