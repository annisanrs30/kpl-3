<?php
ob_start();
session_start();
if (!isset($_SESSION['id'])) {
  header("Location: index_signin.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ANRS Konversi & Balok</title>
<link rel="shortcut icon" href ="img/lg.png">
<style>
* {
  box-sizing: border-box
}
body {
  font-family: Verdana, sans-serif; 
  margin:0;
  background-color: #fff7e3;
}
.navbar nav {
	margin:auto;
	text-align: center;
	width: 100%;
} 
.navbar nav ul ul {
	display: none;
}
.navbar nav ul li:hover > ul{
	display: block;
	width: 150px;
}
.navbar nav ul {
	background: #ffffff00;
	padding: 0 20px;
	list-style: none;
	position: relative;
	display: inline-table;
	width: 100%;
}
.navbar nav ul:after {
	content: ""; 
	clear:both; 
	display: block;
}
.navbar nav ul li{
	float:right;
}
.navbar nav ul li:hover{
	background:#A2A2A2;
}
.navbar nav ul:hover a{
	color: #000;
}
.navbar nav ul li a{
	display: block;
	padding: 25px;
	color: #000;
	text-decoration: none;
  font-family: "Muli", sans-serif;
  font-size: 20px;
}
.navbar nav ul ul{
	background: #FBBC58;
	border-radius: 0px;
	padding: 0;
	position: absolute;
	top:100%;
}
.navbar nav ul ul ul{
	position: absolute;
	right: 100%;
	top: 0;
}

</style>
</head>
<body>
<div class="navbar"><nav>
  <ul>
    <li><a href="index_signin.php">Login</a></li>
    <li><a href="index_signup.php">Register</a></li>
    <li><a href="index_landing.php">Home</a></li>
  </ul>
</nav>
</div>


<div class="wrapper">
  <div class="container-fluid">
  <img src="img/land1.png" style="max-width: 100%;">
</div>
</body>
</html> 

