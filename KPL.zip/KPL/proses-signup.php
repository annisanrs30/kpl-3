<?php
 
 include('functions.php'); 

	if ( isset($_POST["proses"]) ) {   
		$username = $_POST["username"];
		$password = $_POST['password'];
		$email = $_POST["email"];


		//query insert data
		$query = "INSERT INTO user
		VALUES
		('','$username','$email','$password')
				                            ";
				                mysqli_query($conn, $query);

				                // cek apakah data berhasil ditambahkan
				                if (mysqli_affected_rows($conn ) > 0 ) {
				                    echo "<script>
				                        alert('Registrasi Berhasil Silahkan Login');
				                        document.location.href = 'index_signin.php'
				                        </script>";
				                }

				                }

				            ?>