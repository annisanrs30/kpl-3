-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2021 at 02:00 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asa2`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_lat04` (`awal` DATE, `akhir` DATE)  BEGIN
SELECT pp.ID_PEMESANAN, p.NAMA_PEGAWAI, pel.NAMA_PELANGGAN, pp.TGL_SUBMIT_PEMESANAN, pp.TGL_ACARA,
pp.WAKTU_ACARA, jp.PENUNJANG_PESTA, dp.JUMLAH, dp.KETERANGAN, dp.SUBTOTAL, dp.TGL_HRS_KEMBALI
FROM pemesanan pp JOIN pegawai p
ON pp.ID_PEGAWAI = p.ID_PEGAWAI
JOIN pelanggan pel
ON pp.ID_PELANGGAN = pel.ID_PELANGGAN 
JOIN detail_pemesanan dp
ON pp.ID_PEMESANAN= dp.ID_PEMESANAN
JOIN penunjang_pesta jp
ON dp.ID_PENUNJANG = jp.ID_PENUNJANG
WHERE pp.TGL_SUBMIT_PEMESANAN = awal AND dp.TGL_HRS_KEMBALI= akhir;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_lat4_1` (`TglSubmitPsn` DATE, `JatuhTempo` DATE)  BEGIN
SELECT p.ID_PEMESANAN, pe.NAMA_PEGAWAI, pl.NAMA_PELANGGAN, pb.NAMA_BERKAS, p.TGL_SUBMIT_PEMESANAN, p.KETERANGAN_ACARA, p.JATUHTEMPO_PELUNASAN
FROM pemesanan p JOIN pegawai pe ON (p.ID_PEGAWAI = pe.ID_PEGAWAI) JOIN pelanggan pl 
ON (p.ID_PELANGGAN = pl.ID_PELANGGAN) JOIN pembayaran_pemesanan pb ON (p.ID_PEMBAYARAN = pb.ID_PEMBAYARAN) WHERE p.TGL_SUBMIT_PEMESANAN = TglSubmitPsn AND p.JATUHTEMPO_PELUNASAN = JatuhTempo;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `email` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin2', 'ae1d4b431ead52e5ee1788010e8ec110', 'nmwsanti@gmail.com'),
(2, 'admin3', 'f4d9041053a10d5b59e1b0c9c180a210', 'agnysnatalia@gmail.com'),
(3, 'company', 'ee2ba043bbcba84473e01883ef3f0066', 'asaadvertisingofc@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `kepuasan`
--

CREATE TABLE `kepuasan` (
  `id` int(11) NOT NULL,
  `puas` int(5) NOT NULL,
  `cukup` int(5) NOT NULL,
  `kurang` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kepuasan`
--

INSERT INTO `kepuasan` (`id`, `puas`, `cukup`, `kurang`) VALUES
(1, 3, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `resetpassw`
--

CREATE TABLE `resetpassw` (
  `id` int(11) NOT NULL,
  `code` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resetpassw`
--

INSERT INTO `resetpassw` (`id`, `code`, `email`) VALUES
(1, '160933f7a22213', 'asaadvertisingofc@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(300) NOT NULL,
  `email` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(2, 'user1', '827ccb0eea8a706c4c34a16891f84e7b', 'widia.santi5@gmail.com'),
(3, 'user3', 'c9d2cce909ea37234be8af1a1f958805', 'annisa.rusydina@gmail.com'),
(4, 'agnys', 'f4d9041053a10d5b59e1b0c9c180a210', 'agnysnatalia@gmail.com'),
(5, 'agnys2', '995a6f40ecfba2f686355b3d2eebf541', 'imanuela.19032@mhs.unesa.ac.id');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kepuasan`
--
ALTER TABLE `kepuasan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resetpassw`
--
ALTER TABLE `resetpassw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kepuasan`
--
ALTER TABLE `kepuasan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `resetpassw`
--
ALTER TABLE `resetpassw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
