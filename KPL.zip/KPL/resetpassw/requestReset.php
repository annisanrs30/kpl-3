
<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'functions.php';

if(isset($_POST["email"])){

  $emailTo = $_POST["email"];

  $code = uniqid(true);
  $query = mysqli_query($conn, "INSERT INTO resetpassw(code, email) VALUES ('$code', '$emailTo')");
  if(!$query){
    exit("error");
  }


  //Instantiation and passing `true` enables exceptions
  $mail = new PHPMailer(true);

  try {
    //Server settings
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'asaadvertisingofc@gmail.com';                     //SMTP username
    $mail->Password   = 'ASAadv2021';                               //SMTP password
    $mail->SMTPSecure = 'ssl';                                  //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('asaadvertisingofc@gmail.com', 'ASA Advertising');
    $mail->addAddress($emailTo);     //Add a recipient
    $mail->addReplyTo('no-reply@gmail.com', 'No Reply');

    //Content
    $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]) . "/resetpassword.php?code=$code";
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Your Password Reset Link';
    $mail->Body    = "<h1>You Requested a password reset</h1>
                      Click <a href='$url'>This Link</a> to do so";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Reset Password link has been sent to your email';
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }

  exit ();

}

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
 <title>Forgot Password</title>
 <link href="assets/css/bootstrap.min.css" rel="stylesheet">
 <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 <link rel="shortcut icon" href ="img/logoa.png">
 <style>
  body {
   font-family: "Muli", sans-serif;
   background-color: #fff7e3;
  }

#card {
    background: #fbfbfb;
    border-radius: 8px;
    box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
    height: 355px;
    margin: 6rem auto 8.1rem auto;
    width: 759px;
    margin-top: 80px;
    margin-bottom: 70px;
}
body {
    background: #fff7e3;
    background-repeat: no-repeat;
}
#card-content {
    padding: 12px 44px;
}
#card-title {
    font-family: "Muli", sans-serif;
    letter-spacing: 4px;
    padding-bottom: 23px;
    padding-top: 13px;
    text-align: center;
    margin-top: 30px;
}
.underline-title {
    background: -webkit-linear-gradient(right, #fbbc58,  #000);
    height: 2px;
    margin: 0.1rem auto 0 auto;
    width: 614px;
}
a {
    text-decoration: none;
}
label {
    font-family: "Muli", sans-serif;
    font-size: 11pt;
}
#forgot-pass {
    color:#2e302f;
    font-family: "Muli", sans-serif;
    font-size: 10pt;
    margin-top: 3px;
    text-align: right;
}
.form {
    align-items: left;
    display: flex;
    flex-direction: column;
}
.form-border {
    background: -webkit-linear-gradient(right, #fbbc58,  #000);
    height: 1px;
    width: 100%;
}
.form-content {
    background: #fbfbfb;
    border: none;
    outline: none;
    padding-top: 14px;
}
#signup {
    color: #2e302f;
    font-family: "Muli", sans-serif;
    font-size: 10pt;
    margin-top: 16px;
    text-align: center;
}
#submit-btn {
    background: #FBBC58;
    border: none;
    border-radius: 21px;
    box-shadow: 0px 1px 8px #888b8a;
    cursor: pointer;
    color: #000;
    font-family: "Muli", sans-serif;
    height: 42.3px;
    margin: 0 auto;
    margin-top: 50px;
    margin-bottom: 10px;
    transition: 0.25s;
    width: 153px;
    outline: none;
}
#submit-btn:hover {
    box-shadow: 0px 1px 18px#2e302f;
}
.asking {
    margin: auto;
    justify-content: space-between;
    font-family: "Muli", sans-serif;
    font-size: 13px;
}
.footer {
  padding:50px 0;
  color:#000;
  background-color:#fff7e3;
}

.footer .copyright {
  text-align:center;
  padding-top:24px;
  opacity:0.3;
  font-size:13px;
  margin-bottom:0;
}
</style>

</head>
<body>

 <div class="container-fluid" id="codelatte">
    <div id="card"> 
        <div id="card-content">
            <div id="card-title">
              <h2 style="font-size: 30px;">Enter email associated with account</h2>
              <div class="underline-title"></div>
        </div>
        <form method="POST">

            <div class="form-group"> <label for="email-for-pass">Enter your email address</label> <input class="form-control" type="text" id="email-for-pass" required="" autocomplete="off" name="email" > </div>

            <input class="btn btn-primary" type="submit" name="submit" value="Reset Email">

        </form>
    </div>
 </div>
</div>
</body>
</html>